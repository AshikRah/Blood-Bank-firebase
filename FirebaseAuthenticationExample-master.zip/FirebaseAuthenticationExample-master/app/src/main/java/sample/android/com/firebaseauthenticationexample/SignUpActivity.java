package sample.android.com.firebaseauthenticationexample;

import android.content.Intent;
import android.media.MediaCodec;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;

import java.util.regex.Pattern;

public class SignUpActivity extends AppCompatActivity {

    private EditText user, pass, confirmPass;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        initView();

        initVariable();
    }

    private void initVariable() {
      mAuth = FirebaseAuth.getInstance();
    }

    private void initView() {
        user = findViewById(R.id.userEmailForSignUp);
        pass = findViewById(R.id.userPasswordForSignUp);
        confirmPass = findViewById(R.id.userConfirmPasswordForSignUp);
    }


    // --- Sign up to firebase
    public void signUpBtn(View view) {


        if (!validate()) return;

        signUpToFirebase();

    }

    private boolean validate() {

        if (user.getText().toString().trim().isEmpty()){
            user.setError("Pls enter email");
            user.requestFocus();
            return false;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(user.getText().toString().trim()).matches()){

            user.setError("Pls enter a valid email");
            user.requestFocus();
            return false;

        }

        if (pass.getText().toString().trim().isEmpty()){
            pass.setError("Pls enter password");
            pass.requestFocus();
            return  false;
        }

        if (pass.getText().toString().trim().length() < 6){
            pass.setError("Password must be 6 digits");
            pass.requestFocus();
            return false;
        }

        if (!pass.getText().toString().trim().equals(confirmPass.getText().toString().trim())){

            confirmPass.setError("Password not matches");
            confirmPass.requestFocus();
            return false;
        }

        return true;
    }


    // ----- HERE WE SIGN UP TO FIREBASE
    private void signUpToFirebase() {

        mAuth.createUserWithEmailAndPassword(user.getText().toString().trim(), pass.getText().toString().trim())

         .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
             @Override
             public void onComplete(@NonNull Task<AuthResult> task) {

                 if (task.isSuccessful()){

                     Toast.makeText(SignUpActivity.this, "Sign Up Successful", Toast.LENGTH_SHORT).show();
                 }
             }
         }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

                if (e instanceof FirebaseAuthUserCollisionException){
                    Toast.makeText(SignUpActivity.this, "Already registered", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(SignUpActivity.this, "Failed to sign up", Toast.LENGTH_SHORT).show();
                }
            }
        });



    }


    // --- go log in page
    public void logInPage(View view) {

        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
